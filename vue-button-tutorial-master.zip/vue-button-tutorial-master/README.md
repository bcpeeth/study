# vue-button-tutorial

> Creating Reusable Vue.js Components: Button Component

This article for this tutorial can be found [here](https://medium.com/@caseymorrisus/creating-reusable-components-with-vue-js-button-component-503167facfde).

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build
```

For detailed explanation on how things work, consult the [docs for vue-loader](http://vuejs.github.io/vue-loader).