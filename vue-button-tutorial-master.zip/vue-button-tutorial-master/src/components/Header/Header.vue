<template>
<div class="Header">
  <h1>Button Component</h1>
  <p>Creating a reusable button component with Vue.js</p>
</div>
</template>

<style scoped>
.Header {
  margin-bottom: 15px;
}
</style>